﻿using Microsoft.AspNet.SignalR;
using System.Web.Script.Serialization;


public class DataHub : Hub
{
    public void NotifyOthers(string message)
    {
        // Broadcast to everyone else
        Clients.Others.Broadcast(message);

        JavaScriptSerializer serializer = new JavaScriptSerializer();
        CustomersResult customerChanges = serializer.Deserialize<CustomersResult>(message);

        if(customerChanges.Action == "Create")
        {
            // Send message to myself
            Clients.Caller.NotifyMe("Everyone was notified about the newly created Item!");
        }
    }
}

﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Configuration;
using System.Web.Security;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Telerik.Web.UI;

public partial class Default : System.Web.UI.Page 
{
    protected void Grid_Data_PdfExporting(object sender, GridPdfExportingArgs e)
    {

    }

    protected void Grid_Data_NeedDataSource(object sender, GridNeedDataSourceEventArgs e)
    {
        (sender as RadGrid).DataSource = GetTestData();
    }

    protected DataTable GetTestData()
    {
        DataTable tbl = new DataTable();
        tbl.Columns.Add(new DataColumn("id", typeof(decimal)));
        tbl.Columns.Add(new DataColumn("someField", typeof(string)));
        tbl.Columns.Add(new DataColumn("theDates", typeof(DateTime)));
        tbl.Columns.Add(new DataColumn("anotherField", typeof(string)));
        for (int i = 0; i < 15; i++)
        {
            tbl.Rows.Add(new object[] { i, "record" + i, DateTime.Now.AddHours(i), i });
        }


        return tbl;
    }

    protected void RadAjaxManager1_AjaxRequest(object sender, AjaxRequestEventArgs e)
    {
        if (e.Argument == "disablePaging")
        {
            Grid_Data.AllowPaging = false;
            Grid_Data.Rebind();
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "someKey", "Sys.Application.add_load(performExport);", true);
        }
        if (e.Argument == "enablePaging")
        {
            Grid_Data.AllowPaging = true;
            Grid_Data.Rebind();
        }
    }
}

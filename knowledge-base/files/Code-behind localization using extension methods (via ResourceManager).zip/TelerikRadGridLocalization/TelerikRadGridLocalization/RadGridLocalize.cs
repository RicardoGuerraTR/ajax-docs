﻿using Telerik.Web.UI;

namespace TelerikRadGridLocalization
{
    /// <summary>
    /// RadGrid Extensions to Localize the RadGrid-elements
    /// </summary>
    public static class RadGridLocalize
    {
        /// <summary>
        /// Localize the elements of a RadGrid.
        /// </summary>
        public static void Localize(this RadGrid radGrid)
        {
            radGrid.ToolTip = Resources.RadGrid.RadGrid_ToolTip; 

            radGrid.FilterMenu.Localize();
            radGrid.HeaderContextMenu.Localize();
            radGrid.GroupPanel.Localize();
            radGrid.HierarchySettings.Localize();
            radGrid.GroupingSettings.Localize();
            radGrid.ClientSettings.ClientMessages.Localize();
            radGrid.SortingSettings.Localize();
            radGrid.MasterTableView.Localize();
            radGrid.StatusBarSettings.Localize();
            radGrid.PagerStyle.Localize();
        }

        /// <summary>
        /// Localize RadGrid's GridFilterMenu.
        /// </summary>
        public static void Localize(this GridFilterMenu gridFilterMenu)
        {
            foreach (RadMenuItem radMenuItem in gridFilterMenu.Items)
            {
                radMenuItem.Text = Resources.RadGrid.ResourceManager.GetString("FilterMenu_" + radMenuItem.Value) ?? radMenuItem.Text;
            }

            gridFilterMenu.ToolTip = Resources.RadGrid.FilterMenu_ToolTip;
        }
        /// <summary>
        /// Localize RadGrid's GridHeaderContextMenu.
        /// </summary>
        public static void Localize(this GridHeaderContextMenu gridHeaderContextMenu)
        {
            foreach (RadMenuItem radMenuItem in gridHeaderContextMenu.Items)
            {
                radMenuItem.Text = Resources.RadGrid.ResourceManager.GetString("HeaderContextMenu_" + radMenuItem.Value) ??
                                   radMenuItem.Text;
            }

            gridHeaderContextMenu.ToolTip = Resources.RadGrid.HeaderContextMenu_ToolTip; 

        }
        /// <summary>
        /// Localize RadGrid's GridGroupPanel.
        /// </summary>
        public static void Localize(this GridGroupPanel gridGroupPanel)
        {
            gridGroupPanel.Text = Resources.RadGrid.GroupPanel_Text;
            gridGroupPanel.ToolTip = Resources.RadGrid.GroupPanel_ToolTip; 

        }
        /// <summary>
        /// Localize RadGrid's GridGroupingSettings.
        /// </summary>
        public static void Localize(this GridGroupingSettings gridGroupingSettings)
        {
            gridGroupingSettings.GroupContinuesFormatString = Resources.RadGrid.GroupingSettings_GroupContinuesFormatString;
            gridGroupingSettings.GroupContinuedFormatString = Resources.RadGrid.GroupingSettings_GroupContinuedFormatString;
            gridGroupingSettings.ExpandTooltip = Resources.RadGrid.GroupingSettings_ExpandTooltip;
            gridGroupingSettings.CollapseTooltip = Resources.RadGrid.GroupingSettings_CollapseTooltip;
            gridGroupingSettings.UnGroupTooltip = Resources.RadGrid.GroupingSettings_UnGroupTooltip;
            gridGroupingSettings.GroupSplitDisplayFormat = Resources.RadGrid.GroupingSettings_GroupSplitDisplayFormat;
            gridGroupingSettings.UnGroupButtonTooltip = Resources.RadGrid.GroupingSettings_UnGroupButtonTooltip;
            gridGroupingSettings.GroupByFieldsSeparator = Resources.RadGrid.GroupingSettings_GroupByFieldsSeparator;
            gridGroupingSettings.GroupSplitFormat = Resources.RadGrid.GroupingSettings_GroupSplitFormat;


        }
        /// <summary>
        /// Localize RadGrid's GridHierarchySettings.
        /// </summary>
        public static void Localize(this GridHierarchySettings gridHierarchySettings)
        {
            gridHierarchySettings.ExpandTooltip = Resources.RadGrid.HierarchySettings_ExpandTooltip;
            gridHierarchySettings.CollapseTooltip = Resources.RadGrid.HierarchySettings_CollapseTooltip;
            gridHierarchySettings.SelfCollapseTooltip = Resources.RadGrid.HierarchySettings_SelfCollapseTooltip;
            gridHierarchySettings.SelfExpandTooltip = Resources.RadGrid.HierarchySettings_SelfExpandTooltip; 


        }
        /// <summary>
        /// Localize RadGrid's GridClientMessages.
        /// </summary>
        public static void Localize(this GridClientMessages gridClientMessages)
        {
            gridClientMessages.DropHereToReorder = Resources.RadGrid.ClientSettings_ClientMessages_DropHereToReorder;
            gridClientMessages.DragToGroupOrReorder = Resources.RadGrid.ClientSettings_ClientMessages_DragToGroupOrReorder;
            gridClientMessages.DragToResize = Resources.RadGrid.ClientSettings_ClientMessages_DragToResize;
            gridClientMessages.PagerTooltipFormatString = Resources.RadGrid.ClientSettings_ClientMessages_PagerTooltipFormatString;
        }
        /// <summary>
        /// Localize RadGrid's GridSortingSettings.
        /// </summary>
        public static void Localize(this GridSortingSettings gridSortingSettings)
        {
            gridSortingSettings.SortToolTip = Resources.RadGrid.SortingSettings_SortToolTip;
            gridSortingSettings.SortedAscToolTip = Resources.RadGrid.SortingSettings_SortedAscToolTip;
            gridSortingSettings.SortedDescToolTip = Resources.RadGrid.SortingSettings_SortedDescToolTip;
        }
        /// <summary>
        /// Localize RadGrid's MasterTableView.
        /// </summary>
        public static void Localize(this GridTableView gridMasterTableView)
        {
            gridMasterTableView.NoMasterRecordsText = Resources.RadGrid.MasterTableView_NoMasterRecordsText;
            gridMasterTableView.NoDetailRecordsText = Resources.RadGrid.MasterTableView_NoDetailRecordsText;
            gridMasterTableView.Caption = Resources.RadGrid.MasterTableView_Caption;

            gridMasterTableView.CommandItemSettings.AddNewRecordImageUrl = Resources.RadGrid.MasterTableView_CommandItemSettings_AddNewRecordImageUrl;
            gridMasterTableView.CommandItemSettings.AddNewRecordText = Resources.RadGrid.MasterTableView_CommandItemSettings_AddNewRecordText;
            gridMasterTableView.CommandItemSettings.RefreshImageUrl = Resources.RadGrid.MasterTableView_CommandItemSettings_RefreshImageUrl;
            gridMasterTableView.CommandItemSettings.RefreshText = Resources.RadGrid.MasterTableView_CommandItemSettings_RefreshText;

            gridMasterTableView.EditFormSettings.CaptionFormatString = Resources.RadGrid.MasterTableView_EditFormSettings_CaptionFormatString;
            gridMasterTableView.EditFormSettings.EditColumn.CancelText = Resources.RadGrid.MasterTableView_EditFormSettings_EditColumn_CancelText;
            gridMasterTableView.EditFormSettings.EditColumn.EditText = Resources.RadGrid.MasterTableView_EditFormSettings_EditColumn_EditText;
            gridMasterTableView.EditFormSettings.EditColumn.InsertText = Resources.RadGrid.MasterTableView_EditFormSettings_EditColumn_InsertText;
            gridMasterTableView.EditFormSettings.EditColumn.UpdateText = Resources.RadGrid.MasterTableView_EditFormSettings_EditColumn_UpdateText;

            gridMasterTableView.ExpandCollapseColumn.CollapseImageUrl = Resources.RadGrid.MasterTableView_ExpandCollapseColumn_CollapseImageUrl;
            gridMasterTableView.ExpandCollapseColumn.EditFormHeaderTextFormat = Resources.RadGrid.MasterTableView_ExpandCollapseColumn_EditFormHeaderTextFormat;
            gridMasterTableView.ExpandCollapseColumn.ExpandImageUrl = Resources.RadGrid.MasterTableView_ExpandCollapseColumn_ExpandImageUrl;
            gridMasterTableView.ExpandCollapseColumn.FooterText = Resources.RadGrid.MasterTableView_ExpandCollapseColumn_FooterText;
            gridMasterTableView.ExpandCollapseColumn.HeaderImageUrl = Resources.RadGrid.MasterTableView_ExpandCollapseColumn_HeaderImageUrl;
            gridMasterTableView.ExpandCollapseColumn.HeaderText = Resources.RadGrid.MasterTableView_ExpandCollapseColumn_HeaderText;

            gridMasterTableView.RowIndicatorColumn.EditFormHeaderTextFormat = Resources.RadGrid.MasterTableView_RowIndicatorColumn_EditFormHeaderTextFormat;
            gridMasterTableView.RowIndicatorColumn.FooterText = Resources.RadGrid.MasterTableView_RowIndicatorColumn_FooterText;
            gridMasterTableView.RowIndicatorColumn.HeaderImageUrl = Resources.RadGrid.MasterTableView_RowIndicatorColumn_HeaderImageUrl;
            gridMasterTableView.RowIndicatorColumn.HeaderText = Resources.RadGrid.MasterTableView_RowIndicatorColumn_HeaderText; 
        }
        /// <summary>
        /// Localize RadGrid's GridStatusBarItemSettings.
        /// </summary>
        public static void Localize(this GridStatusBarItemSettings gridStatusBarItemSettings)
        {
            gridStatusBarItemSettings.ReadyText = Resources.RadGrid.StatusBarSettings_StatusReadyText;
            gridStatusBarItemSettings.LoadingText = Resources.RadGrid.StatusBarSettings_StatusLoadingText;
        }
        /// <summary>
        /// Localize RadGrid's GridPagerStyle.
        /// </summary>
        public static void Localize(this GridPagerStyle gridPagerStyle)
        {
            gridPagerStyle.PrevPageToolTip = Resources.RadGrid.PagerStyle_PrevPageToolTip;
            gridPagerStyle.PrevPagesToolTip = Resources.RadGrid.PagerStyle_PrevPagesToolTip;
            gridPagerStyle.NextPageToolTip = Resources.RadGrid.PagerStyle_NextPageToolTip;
            gridPagerStyle.NextPagesToolTip = Resources.RadGrid.PagerStyle_NextPagesToolTip;
            gridPagerStyle.PagerTextFormat = Resources.RadGrid.PagerStyle_PagerTextFormat;
            gridPagerStyle.FirstPageToolTip = Resources.RadGrid.PagerStyle_FirstPageToolTip;
            gridPagerStyle.LastPageToolTip = Resources.RadGrid.PagerStyle_LastPageToolTip;
            gridPagerStyle.NextPageText = Resources.RadGrid.PagerStyle_NextPageText;
            gridPagerStyle.PrevPageText = Resources.RadGrid.PagerStyle_PrevPageText;
            gridPagerStyle.PageSizeLabelText = Resources.RadGrid.PagerStyle_PageSizeLabelText;
        }
    }
}

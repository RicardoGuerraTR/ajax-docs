using System;
using TelerikRadGridLocalization;

public partial class Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
        RadGrid1.Localize();
    }

    protected override void OnPreRenderComplete(EventArgs e)
    {
        base.OnPreRenderComplete(e);

        //Translate the RadGrid's HeaderContextMenu
        RadGrid1.HeaderContextMenu.Localize();
    }
}

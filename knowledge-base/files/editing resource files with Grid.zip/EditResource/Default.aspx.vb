﻿Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Data
Imports System.Configuration
Imports System.Web.Security
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Imports Telerik.Web.UI
Imports System.Collections
Imports System.Globalization
Imports System.Resources
Imports System.IO
Imports System.Xml

Module Module1
    Public selectedFile As String
End Module

Public Class _Default
    Inherits System.Web.UI.Page
    Dim viewPaths As Dictionary(Of String, String) = New Dictionary(Of String, String)
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim pathToConfigFile As String = "~/App_Code/MappingFile.mapping"
        Dim configFile As New XmlDocument()
        Dim listViewPaths As List(Of String) = New List(Of String)
        Dim physicalPathToConfigFile As String = Context.Server.MapPath(pathToConfigFile)
        configFile.Load(physicalPathToConfigFile)
        ' Load the configuration file
        Dim rootElement As XmlElement = configFile.DocumentElement

        Dim mappingsSection As XmlNode = rootElement.GetElementsByTagName("Mappings")(0)
        ' get all mappings ;
        For Each mapping As XmlNode In mappingsSection.ChildNodes
            Dim virtualPathAsNode As XmlNode = mapping.SelectSingleNode("child::VirtualPath")
            Dim physicalPathAsNode As XmlNode = mapping.SelectSingleNode("child::PhysicalPath")
            Dim virtualPath As String = PathHelper.RemoveEndingSlash(virtualPathAsNode.InnerText, "\"c)
            Dim physicalPath As String = physicalPathAsNode.InnerText
            listViewPaths.Add(physicalPath)
            viewPaths.Add(PathHelper.RemoveEndingSlash(virtualPath, "/"c), physicalPath)
        Next

        RadFileExplorer1.Configuration.ViewPaths = listViewPaths.ToArray()
        listViewPaths = Nothing
        RadFileExplorer1.Configuration.SearchPatterns = New String() {"*.resx"}
        RadFileExplorer1.Configuration.ContentProviderTypeName = GetType(CustomFileSystemProvider).AssemblyQualifiedName
        Dim aM As RadAjaxManager = RadAjaxManager.GetCurrent(Page)
        AddHandler aM.AjaxRequest, AddressOf RadAjaxManager_AjaxRequest

    End Sub

    Protected Sub RadAjaxManager_AjaxRequest(ByVal sender As Object, ByVal e As Telerik.Web.UI.AjaxRequestEventArgs)
        If Not String.IsNullOrEmpty(e.Argument) AndAlso e.Argument.EndsWith(".resx") Then
            Dim argument As String() = e.Argument.Split("/"c)
            Dim physicalFolder As String = viewPaths(argument(argument.Length - 2))
            selectedFile = physicalFolder + "\" + argument(argument.Length - 1)
            RadGrid1.Rebind()
            lblMsg.Text = "Resource loaded."
        End If
    End Sub

    Protected Sub RadGrid1_NeedDataSource(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridNeedDataSourceEventArgs)

        Dim slist = New SortedList()
        If selectedFile <> String.Empty Then
            Dim stream As Stream = New FileStream(selectedFile, FileMode.Open, FileAccess.Read, FileShare.Read)
            Dim RrX As ResXResourceReader = New ResXResourceReader(stream)
            Dim RrEn As IDictionaryEnumerator = RrX.GetEnumerator()
            While RrEn.MoveNext()
                slist.Add(RrEn.Key, RrEn.Value)
            End While
            RrX.Close()
            stream.Dispose()

        End If
        RadGrid1.DataSource = slist
        If (selectedFile <> String.Empty) Then
            For i As Integer = 0 To RadGrid1.PageSize
                RadGrid1.EditIndexes.Add(i)
            Next
        End If

    End Sub
    Protected Sub RadGrid1_ItemCommand(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridCommandEventArgs) Handles RadGrid1.ItemCommand
        Try
            If selectedFile <> String.Empty Then
                Dim xmlDoc As XmlDocument = New XmlDocument()
                xmlDoc.Load(selectedFile)
                For Each z As GridEditableItem In RadGrid1.EditItems
                    Dim newValues As Hashtable = New Hashtable()
                    z.ExtractValues(newValues)
                    Dim id As Integer = Convert.ToInt32(z.ItemIndex)
                    Dim nlist As XmlNodeList = xmlDoc.GetElementsByTagName("data")
                    Dim childnode As XmlNode = nlist.Item(id)
                    childnode.Attributes("xml:space").Value = "default"
                    Dim lastnode As XmlNode = childnode.SelectSingleNode("value")
                    lastnode.InnerText = CStr(newValues("Value"))
                Next
                xmlDoc.Save(selectedFile)
                lblMsg.Text = "Resource updated."
            End If
        Catch ex As Exception
            lblMsg.Text = "Unable to update " + ex.Message
        End Try
    End Sub
End Class